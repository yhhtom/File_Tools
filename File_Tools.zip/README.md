通过python来提升重命名大量文件的速度，和批量修改文件的扩展名，以及快速创建文件。

一个学习过程中写的小项目，灵感来源于打codeforces的时候创建ABCDE.cpp很麻烦，以及像把.jupyter丢给AI的时候重命名成.txt很麻烦。之后可能会加其他功能。

直接点击run.bat运行，然后根据显示内容操作就行。默认是操作自带的同一目录下的Input文件夹里的文件。

Speed up renaming a large number of files by python, and modify the extension of multiple files at the same time, and quickly creat a lot of files.

A small project written during learning, inspired by the need to create ABCDE.cpp when playing codeforces, and the need to rename .jupyter to .txt when giving it to AI, may add other features later.

Just run run.bat, and follow the instructions. By default it will modify files in the Input folder under the current directory.

🙂😇😍🤖☺️😋