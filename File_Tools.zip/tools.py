tools_list=[
'extension_converter', 
'massive_renamer',
'file_creator'
]
def main(s):
    for a,b in enumerate(tools_list):
        print(a+1,b,sep=': ')